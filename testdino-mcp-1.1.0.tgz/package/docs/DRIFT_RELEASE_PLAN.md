# testdino-mcp — Drift Catch-Up Release Plan (3 parts, 3 PRs)

Drift snapshot: `docs/STREAMING_DRIFT.md`.
Streaming (source of truth): `microservices/services/mcp/node/src/mcp/streaming/modules/`.

The catch-up ships in **three independent PRs**, each on its own branch,
against `main`. They can ship in this order without any coordination with
the server — every stdio backend route already exists.

---

## Ordering rationale

| Part | Theme                    | Risk                                 | Why this order                                                                                                                                                                                                                                                                    |
| ---- | ------------------------ | ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1    | Audit refactor           | Medium — splits an existing tool     | **This is the only drift item that is actively wrong today** — `test_audit` in the npm doesn't match the streaming shape (missing `branchSignals`, monolithic tool that upstream has already split for the MCP safety model). Shipping this first stops the wrong-behavior clock. |
| 2    | `get_run_error_clusters` | Very low — single new read-only tool | Small, pure read, zero user risk. Rides after the audit fix as a clean warm-up before the integrations block.                                                                                                                                                                     |
| 3    | Integrations (4 tools)   | Low — 4 new tools, 2 read + 2 write  | Cohesive feature block. High business value (this is what MCP users have been asking for). Independent of Parts 1 and 2.                                                                                                                                                          |

Version bumps: `1.0.10` → `1.1.0` → `1.2.0` → `1.3.0`. Each part gets a minor
bump; the audit alias only breaks in a future `2.0.0`.

---

## Part 2 — Error clustering (`v1.2.0`)

**Branch:** `feat/run-error-clusters`
**PR title:** `feat: add get_run_error_clusters tool (v1.2.0)`

### Scope

- Register one new read-only tool: **`get_run_error_clusters`**.
- Streaming ref: `modules/test-runs/testRuns.tools.ts:134`.
- Input schema (verbatim from streaming):
  - `projectId` — string, required.
  - `testrun_id` — string, required.
  - `status` — enum `'all' | 'failed' | 'flaky'`, optional.
- Wire endpoint (stdio backend already serves):
  `GET /api/mcp/{projectId}/run-error-clusters?testrun_id=…&status=…`

### Files to add / edit

- `src/tools/testruns/get-run-error-clusters.ts` — new tool definition.
- `src/lib/endpoints.ts` — add `runErrorClusters(projectId)` constant.
- `src/tools/index.ts` — register the tool.
- `tests/tools/testruns/get-run-error-clusters.test.ts` — schema + happy-path fetch mock.
- `README.md` — one-line addition under the test-runs tools list.
- `package.json` — bump to `1.2.0`.
- `CHANGELOG.md` — `## 1.2.0` entry.

### Ship checklist

- [ ] Local smoke: `npx testdino-mcp` against a monorepo `make mcp-dev`, invoke tool from Cursor.
- [ ] Unit tests green.
- [ ] `docs/STREAMING_DRIFT.md` — mark `get_run_error_clusters` row as ✅ shipped.
- [ ] Tag `v1.2.0`, publish to npm.

---

## Part 3 — Integrations (`v1.3.0`)

**Branch:** `feat/integrations-tools`
**PR title:** `feat: add integrations tool suite (v1.3.0)`

### Scope

Four new tools that expose the integrations feature block:

| Tool                     | Op    | Streaming ref                                    |
| ------------------------ | ----- | ------------------------------------------------ |
| `get_integration_status` | read  | `modules/integrations/integrations.tools.ts:397` |
| `connect_integration`    | write | `modules/integrations/integrations.tools.ts:453` |
| `create_external_issue`  | write | `modules/integrations/integrations.tools.ts:495` |
| `get_external_issue`     | read  | `modules/integrations/integrations.tools.ts:623` |

Wire endpoints (all served by stdio backend today):

- `GET /api/mcp/{projectId}/integration-status?provider=…`
- `POST /api/mcp/{projectId}/integration/connect-url`
- `POST /api/mcp/{projectId}/external-issue`
- `GET /api/mcp/{projectId}/external-issue/{issueId}`

### Files to add / edit

- `src/tools/integrations/get-integration-status.ts`
- `src/tools/integrations/connect-integration.ts`
- `src/tools/integrations/create-external-issue.ts`
- `src/tools/integrations/get-external-issue.ts`
- `src/lib/endpoints.ts` — 4 new endpoint constants.
- `src/tools/index.ts` — register all 4 tools.
- `tests/tools/integrations/*.test.ts` — 4 test files, one per tool.
- `README.md` — new "Integrations" section listing all 4 tools + `provider` values supported.
- `package.json` — bump to `1.3.0`.
- `CHANGELOG.md` — `## 1.3.0` entry.

### Design decisions to make before coding

- [ ] `provider` allowed values — mirror streaming's enum verbatim. Do NOT invent new provider strings.
- [ ] `create_external_issue` idempotency-key — required from the caller, or generated client-side and returned? Streaming allows caller-supplied; keep the same behavior.
- [ ] `connect_integration` returns a URL. The npm package should NOT try to open it — return the URL as tool output and let the AI client show it to the user.

### Ship checklist

- [ ] Local smoke against a real connected integration (Jira or monday) in dev.
- [ ] Unit tests for all 4 tools.
- [ ] `docs/STREAMING_DRIFT.md` — mark 4 rows as ✅ shipped.
- [ ] Tag `v1.3.0`, publish to npm.

---

## Part 1 — Audit refactor (`v1.1.0`)

**Branch:** `refactor/audit-split`
**PR title:** `feat: split test_audit into read + write tools, add branchSignals (v1.1.0)`

### Scope

- Add **`get_audit_report`** (read-only) — actions `'context' | 'list' | 'get'`.
  Streaming ref: `modules/test-runs/audit.tools.ts:71`.
- Add **`submit_audit_report`** (write-only). Streaming ref: `modules/test-runs/audit.tools.ts:248`.
- Surface `branchSignals` (`topFailingTests`, `topFlakyTests`, `topSlowTests`) from `get_audit_report(action='context')`. Include the field in the tool's output schema so the AI client sees it structured.
- Keep **`test_audit`** registered as a **deprecated alias** that internally
  delegates:
  - `action='analyze'` (no submission fields) → `get_audit_report(action='context')`.
  - `action='analyze'` (with score/findings) → `submit_audit_report(...)`.
  - `action='list'` → `get_audit_report(action='list')`.
  - `action='get'` → `get_audit_report(action='get')`.
- On the first `test_audit` invocation per process, log a one-line deprecation notice to stderr (not to the tool response — MCP clients pipe stderr for humans).

Wire endpoints (already served; no server work):

- `GET /api/mcp/{projectId}/audit-context?branch=…`
- `POST /api/mcp/{projectId}/audit-report`
- `GET /api/mcp/{projectId}/audit-reports`
- `GET /api/mcp/{projectId}/audit-reports/{reportId}`

### Files to add / edit

- `src/tools/audits/get-audit-report.ts` — new.
- `src/tools/audits/submit-audit-report.ts` — new.
- `src/tools/audits/test-audit.ts` — trim to a thin alias that delegates; add stderr deprecation notice; do NOT delete the file yet.
- `src/tools/audits/audit-categories.ts` — audit whether the categories helper still fits both new tools; adjust if needed.
- `src/lib/endpoints.ts` — no new endpoints; may split existing constant names for clarity.
- `src/tools/index.ts` — register the two new tools; keep `test_audit`.
- `tests/tools/audits/get-audit-report.test.ts` — new.
- `tests/tools/audits/submit-audit-report.test.ts` — new.
- `tests/tools/audits/test-audit.test.ts` — update to assert on the alias delegation, not the removed behavior.
- `README.md` — replace the `test_audit` section with the two new tools; leave a deprecation callout for `test_audit`.
- `CLAUDE.md` — update the audit workflow guidance to steer AI to the new tools.
- `package.json` — bump to `1.1.0`.
- `CHANGELOG.md` — `## 1.1.0` entry, explicitly call out deprecation.

### Backward-compat contract

- Any AI client that has been told to call `test_audit(action='analyze', …)` MUST keep working after `v1.1.0` — the alias exists for that.
- `test_audit` is removed in `v2.0.0` (no date set yet).

### Ship checklist

- [ ] Local smoke: existing Cursor configs that call `test_audit` still work end-to-end.
- [ ] Local smoke: new configs calling `get_audit_report` / `submit_audit_report` work end-to-end.
- [ ] `branchSignals` visible in the `action='context'` output.
- [ ] Deprecation notice fires exactly once per process for `test_audit`.
- [ ] `docs/STREAMING_DRIFT.md` — mark audit-split row as ✅ shipped.
- [ ] Tag `v1.1.0`, publish to npm.

---

## Cross-cutting rules for all 3 PRs

- **Do not touch `src/lib/request.ts` or `src/lib/env.ts`** unless a bug surfaces during the ship. Auth + base URL are unchanged; keep the diff scoped to tool surface.
- **Read the streaming implementation before writing each tool.** Do not invent a schema — the point of catching up is that the source-of-truth already defines the shape.
- **Every new tool needs a unit test** that (a) validates the schema against a happy-path input and (b) mocks the fetch and asserts the endpoint path + method + headers. The bar is behavior, not padding.
- **Every PR bumps `package.json` version, appends to `CHANGELOG.md`, and updates `README.md`.** No exceptions.
- **After each ship, tick the corresponding row in `docs/STREAMING_DRIFT.md`** so this doc reflects reality. When all three parts have shipped, delete the drift doc — it will be stale.

---

## Timeline (rough)

Not committed dates — flag if any of these need firming up before the branch is cut.

| Part               | Effort estimate | Blockers                                                                                                                         |
| ------------------ | --------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| 1 (error clusters) | Half a day      | None.                                                                                                                            |
| 2 (integrations)   | 1–2 days        | Need a working Jira or monday connection in the dev env to smoke `create_external_issue`.                                        |
| 3 (audit refactor) | 1 day           | None — but the deprecation-alias work needs a careful review to make sure no existing `test_audit` behavior is silently dropped. |
