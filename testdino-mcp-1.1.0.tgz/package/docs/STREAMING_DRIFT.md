# testdino-mcp: Drift vs. Streaming MCP (source of truth)

Snapshot taken **2026-07-09** against:

- **npm package (this repo):** `testdino-mcp@1.0.10`
- **Streaming MCP (monorepo, source of truth):**
  `microservices/services/mcp/node/src/mcp/streaming/modules/`

The stdio backend (`.../src/mcp/stdio/`) already routes every drift item below —
so no server changes are required. The gap is purely on the npm client:
tools that need registering, one tool that needs a split, and one payload
shape that needs surfacing.

---

## 1. Missing tools (npm has none of these) — 5

| Tool                     | Category             | Streaming ref                                    | Notes                                                                                                                                                                   |
| ------------------------ | -------------------- | ------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `get_run_error_clusters` | Test runs (read)     | `modules/test-runs/testRuns.tools.ts:134`        | Groups failing tests in a run by error signature. Input: `projectId`, `testrun_id` (required), `status` ∈ `all` \| `failed` \| `flaky` (optional). Critical for triage. |
| `get_integration_status` | Integrations (read)  | `modules/integrations/integrations.tools.ts:397` | Reports whether Jira / monday.com / … is connected for a project. Prerequisite for the create flow.                                                                     |
| `connect_integration`    | Integrations (write) | `modules/integrations/integrations.tools.ts:453` | Returns an OAuth connect URL for the requested provider.                                                                                                                |
| `create_external_issue`  | Integrations (write) | `modules/integrations/integrations.tools.ts:495` | Files a Jira / monday issue with idempotency-key. Fields: `provider`, `source`, `summary`, `description`, provider fields, `linkBack`, `idempotencyKey`.                |
| `get_external_issue`     | Integrations (read)  | `modules/integrations/integrations.tools.ts:623` | Fetches an external issue by ID.                                                                                                                                        |

Stdio backend routes already exist under `/api/mcp/{projectId}/*` — see
`microservices/services/mcp/node/src/mcp/stdio/modules/integrations/` and
`.../test-runs/`. No server work required to add these tools on the client.

---

## 2. Shape drift — 1 tool

### `test_audit` → `get_audit_report` + `submit_audit_report` — ✅ SHIPPED in v1.1.0

- **npm today:** one omnibus tool `test_audit(action='analyze'|'list'|'get', …)`.
  See `src/tools/audits/test-audit.ts:52`.
- **Streaming today:** split into two tools per MCP safety model (read vs. write):
  - `get_audit_report(action='context'|'list'|'get')` — read-only.
    `modules/test-runs/audit.tools.ts:71`.
  - `submit_audit_report(...)` — write-only.
    `modules/test-runs/audit.tools.ts:248`.
- **Additional gain:** `get_audit_report(action='context')` now returns
  computed `branchSignals` (`topFailingTests`, `topFlakyTests`, `topSlowTests`).
  npm's `test_audit(action='analyze')` doesn't surface these yet — the LLM
  is left to derive them.

Migration plan for npm:

1. Add `get_audit_report` + `submit_audit_report` as new registrations, using
   the streaming schema verbatim (both hit routes the stdio backend already
   serves).
2. Keep `test_audit` for one minor version (`1.1.x`) as a **deprecated alias**
   that internally delegates to the new tools. Log a deprecation notice on the
   first invocation per process.
3. Drop `test_audit` in `2.0.0`.

---

## 3. What's NOT drifted

| Area                        | State                                                                                                                                      |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| Auth                        | Same `Bearer <PAT>` header both sides.                                                                                                     |
| Base URL / endpoint paths   | Same `/api/mcp/{projectId}/*` shape. `src/lib/endpoints.ts` needs new entries for the integration + error-cluster routes, nothing renamed. |
| Rate limiting               | Server enforces the same `mcpRateLimit` middleware for both transports. Nothing client-side.                                               |
| Existing tools (26 of them) | Every current npm tool still maps to a live streaming tool of the same name. No orphans.                                                   |

---

## 4. Recommended catch-up order

| #   | Change                                                                                                                                | Bump    |
| --- | ------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| 1   | Register the 5 missing tools. Integration tools first (highest business value — actual user asks).                                    | `1.1.0` |
| 2   | Split `test_audit` into `get_audit_report` + `submit_audit_report`, surface `branchSignals`. Keep `test_audit` as a deprecated alias. | `1.1.0` |
| 3   | Publish + update README with the new tool list.                                                                                       | `1.1.0` |
| 4   | (Later) Drop `test_audit` alias.                                                                                                      | `2.0.0` |

---

## 5. Verification checklist per new tool

For each of the 5 missing tools:

- [ ] Add tool definition under `src/tools/<category>/<tool-name>.ts` mirroring
      the input schema in the streaming file cited above.
- [ ] Add the endpoint constant to `src/lib/endpoints.ts` (same path shape as
      existing tools).
- [ ] Register the tool in `src/tools/index.ts`.
- [ ] Unit test the schema + happy-path client call (mock the fetch).
- [ ] Smoke test end-to-end against a running MCP service in the monorepo:
      `make mcp-dev` in `microservices/`, then invoke the tool from Cursor
      pointed at localhost.

---

## References

- Streaming (source of truth): `microservices/services/mcp/node/src/mcp/streaming/modules/`
- Stdio backend (what npm calls): `microservices/services/mcp/node/src/mcp/stdio/modules/`
- Shared HTTP clients (both transports call these):
  `microservices/services/mcp/node/src/shared/clients/`
